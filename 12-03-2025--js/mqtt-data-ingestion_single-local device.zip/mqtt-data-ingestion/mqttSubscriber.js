require("dotenv").config();
const mqtt = require("mqtt");
const { normalizeData, storeDataInMySQL } = require("./dataProcessor");

//MQTT Broker URL and Topic
const brokerUrl = process.env.MQTT_BROKER || "mqtt://localhost:1883";
const topic = process.env.MQTT_TOPIC || "iot/sensor/data";


const client = mqtt.connect(brokerUrl);

client.on("connect", () => {
    console.log(`Connected to MQTT broker at ${brokerUrl}`);
    client.subscribe(topic, (err) => {
        if (!err) {
            console.log(`Subscribed to topic: ${topic}`);
        }
    });
});

client.on("message", async (topic, message) => {
    try {
        console.log("Received raw message:", message.toString());
        const normalizedData = normalizeData(message.toString());
        await storeDataInMySQL(normalizedData);
    } catch (error) {
        console.error("Error processing message:", error);
    }
});
